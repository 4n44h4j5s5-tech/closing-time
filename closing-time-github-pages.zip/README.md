# CLOSING TIME — The Application Prototype

This is a static, self-contained HTML5 prototype. It has no build step and no external
JavaScript or CSS dependencies. The entry point is `index.html`.

## Publish with GitHub Pages

1. Sign in to GitHub and create a new repository.
2. Give it a name such as `closing-time`.
3. Set visibility to **Public** (GitHub Pages on the free plan generally requires a public repository).
4. Create the repository.
5. Choose **Add file → Upload files**.
6. Upload `index.html` from this folder (not the ZIP file).
7. Commit the upload to the `main` branch.
8. Open the repository's **Settings → Pages**.
9. Under **Build and deployment**, choose **Deploy from a branch**.
10. Select branch **main**, folder **/(root)**, then press **Save**.
11. Wait for GitHub Pages to publish. The Pages screen will show the website address.

Open that address in Safari on the iPhone. Add it to the Home Screen from Safari's
Share menu if you want an app-like shortcut.

## Notes

- The game saves progress in the browser's local storage. Use the same browser and
  website address to continue that save.
- Clearing Safari website data can erase the local save. Use the in-game Save control
  and export important records where available.
- This is an early recruitment/induction prototype, not the complete CLOSING TIME RPG.
